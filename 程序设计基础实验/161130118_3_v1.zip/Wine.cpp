#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>

struct ATT // ������ֵ
{
	double max;
	double min;
	double avg;
	ATT()
	{
		max = min = avg = 0.0;
	}
};

void GetAtt(double (&wine)[178][14], ATT (&att)[13])
{
	for (int i = 1; i < 14; i++)
	{
		double max, min, avg, sum;
		int count = 0;
		max = min = wine[0][i];
		avg = sum = 0.0;
		for (int j = 0; j < 178; j++)
		{
			if (wine[j][i] > max)
				max = wine[j][i];
			if (wine[j][i] != -1.0) // ����#
			{
				if (wine[j][i] < min)
					min = wine[j][i];
				sum += wine[j][i];
				count++;
			}
		}
		avg = sum / count;
		att[i - 1].max = max;
		att[i - 1].min = min;
		att[i - 1].avg = avg;
	}
}

void SetWine(double (&wine)[178][14], ATT (&att)[13])
{
	for (int i = 0; i < 178; i++)
		for (int j = 1; j < 14; j++)
			if (wine[i][j] == -1.0)
				wine[i][j] = att[j - 1].avg;
}

void Setcpl(FILE *cpl, double (&wine)[178][14])
{
	char ch = ',';
	char end = '\n';
	for (int i = 0; i < 178; i++)
	{
		for (int j = 0; j < 13; j++)
		{
			fwrite(&wine[i][j], sizeof(double), 1, cpl);
			fwrite(&ch, sizeof(ch), 1, cpl);
		}
		fwrite(&wine[i][13], sizeof(double), 1, cpl);
		fwrite(&end, sizeof(end), 1, cpl);
	}
}

void Readcpl(FILE *cpl)
{
	rewind(cpl); // ָ�븴ԭ
	char ch;
	double num;
	for (int i = 0; i < 178; i++)
		for (int j = 0; j < 14; j++)
		{
			fread(&num, sizeof(num), 1, cpl);
			fread(&ch, sizeof(ch), 1, cpl);
			printf("%.1lf%c", num, ch);
		}
}

void Normalize(double (&wine)[178][14], ATT (&att)[13])
{
	for (int i = 0; i < 178; i++)
		for (int j = 1; j < 14; j++)
		{
			if (att[j - 1].max == att[j - 1].min)
				wine[i][j] = 1.0;
			else
				wine[i][j] = (wine[i][j] - att[j - 1].min) / (att[j - 1].max - att[j - 1].min);
		}
}

void Setnorm(FILE *norm, double (&wine)[178][14])
{
	for (int i = 0; i < 178; i++)
	{
		for (int j = 0; j < 13; j++)
			fprintf(norm, "%.1lf,", wine[i][j]);
		fprintf(norm, "%.1lf\n", wine[i][13]);
	}
}

int main()
{
	FILE *source = fopen("wine.txt", "r");
	FILE *cpl = fopen("wine_cpl.dat", "wb+"); 
	FILE *norm = fopen("wine_norm.csv", "w");
	ATT att[13]; // ����ÿ�е����, ��С, ƽ��ֵ
	double wine[178][14] = { 0 }; // ����wine.txt
	for (int i = 0; i < 178; i++)
	{
		for (int j = 0; j < 14; j++)
		{
			if (!fscanf(source, "%lf,", &wine[i][j])) // ����#, ��ǰλ��д��-1, �ļ�ָ�������ƶ������ֽ�(#,)
			{
				wine[i][j] = -1.0;
				fseek(source, 2, 1);
			}
		}
	}
	GetAtt(wine, att); // ͳ��ÿ�е����, ��С, ƽ��ֵ
	SetWine(wine, att); // ����ȱʧֵ
	Setcpl(cpl, wine); // д��������ļ�
	Readcpl(cpl); // ��ȡ�������ļ�(�Բ���)
	Normalize(wine, att); // ��һ������
	Setnorm(norm, wine); // д��csv�ļ�
	fclose(source);
	fclose(cpl);
	fclose(norm);
}