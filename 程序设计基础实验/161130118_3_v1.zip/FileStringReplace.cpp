#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<string.h>

int main()
{
	char str[101] = { 0 };
	int start = 0;
	scanf("%d %s", &start, str);
	FILE *fp = fopen("sample.txt", "r+");
	fseek(fp, start - 1, 0);
	int len = strlen(str);
	for (int i = 0; i < len; i++)
		fputc(str[i], fp);
	fclose(fp);
}