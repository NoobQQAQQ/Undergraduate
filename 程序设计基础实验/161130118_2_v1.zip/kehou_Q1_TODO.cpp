#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// �����С 
#define MAX_SIZE 1000

#define sort(array, arraySize)\
{\
	for (int i = 0; i < arraySize; i++)\
		for (int j = i + 1; j < arraySize; j++)\
			if (array[i] > array[j])\
			{\
				array[i] ^= array[j];\
				array[j] ^= array[i];\
				array[i] ^= array[j];\
			}\
}

int main()
{
	//NOTE:�������������в��� 
	int data[MAX_SIZE], n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		int m;
		puts("*****************");
		scanf("%d", &m);
		for (int j = 0; j < m; j++)
			scanf("%d", data + j);
		sort(data, m);
		puts("after sorting:");
		for (int j = 0; j < m; j++)
		{
			printf("%d ", data[j]);
		}
		puts("\n*****************");
	}
	return 0;	
}

// NOTE: ����ע��Ƭ���ǲ��Դ��룬�����޸ģ����޸ĺ����̲��Գ��ִ��� ����Ը� 
/*

int main()
{
	int data[MAX_SIZE] , n;
	scanf("%d",&n);
	for(int i = 0 ; i < n ; i++)
	{
		int m;
		puts("*****************");
		scanf("%d",&m);
		for(int j = 0 ; j < m ; j++)
			scanf("%d",data+j); 
		sort(data, m);
		puts("after sorting:");
		for(int j = 0 ; j < m ; j++)
		{
			printf("%d ",data[j]);
		}
		puts("\n*****************");
	}
	
	return 0;	
}
*/

