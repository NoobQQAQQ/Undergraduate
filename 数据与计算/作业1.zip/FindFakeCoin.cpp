#include<iostream>
#include<cstdio>

using namespace std;

// return weight of coins in [head, tail]
inline int weigh(int *arr, int head, int tail) 
{
	int sum = 0;
	for (int i = head; i <= tail; i++)
		sum += arr[i];
	return sum;
}

void find(int *arr, int head, int tail)
{
	static int count = 0; // record how many times we used during the whole process
	if (head == tail)
	{
		cout << "find the fake coin with No." << head << endl;
		cout << "Total weighing times: " << count << endl;
		return;
	}
	// partition into 2 parts
	int len = tail - head + 1;
	count++; // simulate the process of weighing
	if (len % 2 == 0)
	{
		printf("compare coins in [%d, %d] with [%d, %d]\n", head, head + len / 2 - 1, head + len / 2, tail);
		int m1, m2;
		m1 = weigh(arr, head, head + len / 2 - 1);
		m2 = weigh(arr, head + len / 2, tail);
		if (m1 < m2)
		{
			printf("the fake coin is in [%d, %d]\n", head, head + len / 2 - 1);
			find(arr, head, head + len / 2 - 1);
		}
		else
		{
			printf("the fake coin is in [%d, %d]\n", head + len / 2, tail);
			find(arr, head + len / 2, tail);
		}
	}
	else
	{
		printf("compare coins in [%d, %d] with [%d, %d]\n", head, head + ((len - 1) / 2) - 1, head + ((len - 1) / 2), tail - 1);
		int m1, m2;
		m1 = weigh(arr, head, head + ((len - 1) / 2) - 1);
		m2 = weigh(arr, head + ((len - 1) / 2), tail - 1);
		if (m1 == m2)
		{
			cout << "find the fake coin with No." << tail << endl;
			cout << "Total weighing times: " << count << endl;
			return;
		}
		else if (m1 < m2)
		{
			printf("the fake coin is in [%d, %d]\n", head, head + ((len - 1) / 2) - 1);
			find(arr, head, head + ((len - 1) / 2) - 1);
		}
		else
		{
			printf("the fake coin is in [%d, %d]\n", head + ((len - 1) / 2), tail - 1);
			find(arr, head + ((len - 1) / 2), tail - 1);
		}
	}
}

int main()
{
	int n, m;
	cout << "Please first input the number of coins, then indicate which one(index here starting with 0) is fake:\n";
	cin >> n >> m;
	int *arr = new int[n];
	// fake coin weighs -1, others 0
	for (int i = 0; i < n; i++)
		arr[i] = (i == m) ? -1 : 0;
	find(arr, 0, n - 1);
}