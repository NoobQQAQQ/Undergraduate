#include<iostream>
#include<string>
#include<fstream>

using namespace std;

const int MAX_SIZE = 2000;

struct Student
{
	string id;
	string name;
	Student(){}
};

int getStudent(Student *students)
{
	int num = 0;
	fstream fin;
	fin.open("test.txt");
	while (!fin.eof())
	{
		fin >> students[num].id;
		fin >> students[num++].name;
	}
	fin.close();
	return num;
}

void find(string id, Student *students, int head, int tail)
{
	if (tail < head)
		cout << "ѧ�Ŵ���, û�и���!" << endl;
	else
	{
		int mid = (head + tail) / 2;
		if (students[mid].id == id)
			cout << "ѧ��Ϊ" << id << "��ѧ��������" << students[mid].name << endl;
		else if (students[mid].id < id)
			find(id, students, mid + 1, tail);
		else
			find(id, students, head, mid - 1);
	}
}

int main()
{
	Student students[MAX_SIZE];
	int numStudent = getStudent(students);
	while (1)
	{
		string id;
		cout << "�����ѯѧ��: " << endl;
		cin >> id;
		find(id, students, 0, numStudent - 1);
	}
}