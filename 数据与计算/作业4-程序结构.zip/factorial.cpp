#include<iostream>

using namespace std;

typedef long long ll;

ll fac_itr(int n)
{
	ll ans = 1;
	while (n)
	{
		ans *= n--;
	}
	return ans;
}

ll fac_rec(int n)
{
	if (n == 0)
		return 1;
	if (n == 1 || n == 2)
		return n;
	return n * fac_rec(n - 1);
}

int main()
{
	int n;
	while (cin >> n)
	{
		cout << "the result of iteration: " << fac_itr(n) << endl;
		cout << "the result of recursion: " << fac_rec(n) << endl;
	}
}