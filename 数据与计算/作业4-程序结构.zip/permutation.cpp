#include<iostream>

using namespace std;

void swap(int &x, int &y)
{
	int temp = x; x = y; y = temp;
}

void P(int *arr, int left, int right)
{
	if (left == right)
	{
		for (int i = 0; i <= right; i++)
			cout << arr[i];
		cout << endl;
	}
	else
	{
		for (int i = left; i <= right; i++)
		{
			swap(arr[left], arr[i]);
			P(arr, left + 1, right);
			swap(arr[left], arr[i]);
		}
	}
}

int main()
{
	int n;
	while (cin >> n)
	{
		int *arr = new int[n];
		for (int i = 0; i < n; i++)
			arr[i] = i + 1;
		P(arr, 0, n - 1);
	}
}