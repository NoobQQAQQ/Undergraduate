#include<iostream>
#include<cstdlib>
#include<algorithm>
#include<queue>
#include<ctime>
using namespace std;

const int ODD_SIZE = 127;
const int EVEN_SIZE = 128;

// an online algorithm, the usage of double heaps can achieve the following two things:
// 1. insert one coming data in O(logn) time
// 2. get median of current datas in O(1) time
// which means, for its offline version, we can do median getting in O(nlogn) time
// this algorithm is not best suitable for the application scenario given by problem
// another algorithm is implemented in function find_median1(), which can find median in expected O(n) time
class doubleHeap
{
public:
	doubleHeap(int *arr, int size)
	{
		delta = 0;
		for (int i = 0; i < size; i++)
			insert(arr[i]);
	}
	~doubleHeap() {};
	void insert(int n)
	{
		// initial case
		if (maxHeap.size() == 0 && minHeap.size() == 0)
		{
			minHeap.push(n);
			delta++;
		}
		else
		{
			if (delta == 1)
			{
				if (n > minHeap.top())
				{
					int top = minHeap.top();
					minHeap.pop();
					minHeap.push(n);
					maxHeap.push(top);
				}
				else
					maxHeap.push(n);
				delta--;
			}
			else if (delta == -1)
			{
				if (n < maxHeap.top())
				{
					int top = maxHeap.top();
					maxHeap.pop();
					maxHeap.push(n);
					minHeap.push(top);
				}
				else
					minHeap.push(n);
				delta++;
			}
			else if (delta == 0)
			{
				if (n > minHeap.top())
				{
					minHeap.push(n);
					delta++;
				}
				else
				{
					maxHeap.push(n);
					delta--;
				}
			}
		}
	}
	double get_median()
	{
		if (delta == 1)
			return minHeap.top();
		else if (delta == -1)
			return maxHeap.top();
		else if (delta == 0)
			return ((double)minHeap.top() + (double)maxHeap.top()) / 2;
		else
			cout << "error in get_median()" << endl;
	}
private:
	priority_queue<int, vector<int>, less<int> > maxHeap;
	priority_queue<int, vector<int>, greater<int> > minHeap;
	int delta; // minHeap.size - maxHeap.size
};

int my_partition(int *arr, int left, int right)
{
	int pivot = arr[left];
	int i = left, j = right;
	while(i < j)
	{
		while (arr[j] >= pivot && i < j)
			j--;
		while (arr[i] <= pivot && i < j)
			i++;
		swap(arr[i], arr[j]);
	}
	swap(arr[i], arr[left]);
	return i;
}

double find_max(int *arr, int left, int right)
{
	int max = arr[left];
	for (int i = left + 1; i <= right; i++)
		if (arr[i] > max)
			max = arr[i];
	return max;
}

double find_median1(int *arr, int size)
{
	int k = my_partition(arr, 0, size - 1);
	while (k != size / 2)
	{
		if (k > size / 2)
			k = my_partition(arr, 0, k - 1);
		else
			k = my_partition(arr, k + 1, size - 1);
	}
	if (size % 2 == 0)
	{
		double tmp = find_max(arr, 0, k - 1);
		return (tmp + arr[k]) / 2;
	}
	else
		return arr[k];
}

double find_median2(int *arr, int size)
{
	doubleHeap dh = doubleHeap(arr, size);
	return dh.get_median();
}

int	main()
{
	int odd1[ODD_SIZE] = {};
	int odd2[ODD_SIZE] = {};
	int test_odd[ODD_SIZE] = {}; // for test only
	int even1[EVEN_SIZE] = {};
	int even2[EVEN_SIZE] = {};
	int test_even[EVEN_SIZE] = {}; // for test only
	
	// generate random data for test
	srand((unsigned)time(NULL));
	for (int i = 0; i < ODD_SIZE; i++)
	{
		odd1[i] = rand();
		odd2[i] = odd1[i];
		test_odd[i] = odd1[i];
	}
	for (int i = 0; i < EVEN_SIZE; i++)
	{
		even1[i] = rand();
		even2[i] = even1[i];
		test_even[i] = even1[i];
	}

	// use STL to generate correct median
	nth_element(test_odd, test_odd + (ODD_SIZE - 1) / 2, test_odd + ODD_SIZE);
	double std_odd_median = test_odd[(ODD_SIZE - 1) / 2];
	nth_element(test_even, test_even + EVEN_SIZE / 2 - 1, test_even + EVEN_SIZE);
	nth_element(test_even, test_even + EVEN_SIZE / 2, test_even + EVEN_SIZE);
	double std_even_median1 = test_even[EVEN_SIZE / 2 - 1];
	double std_even_median2 = test_even[EVEN_SIZE / 2];
	double std_even_median = (std_even_median1 + std_even_median2) / 2;
	
	// use my function to generate median
	double my_odd_median1 = find_median1(odd1, ODD_SIZE);
	double my_even_median1 = find_median1(even1, EVEN_SIZE);
	double my_odd_median2 = find_median2(odd2, ODD_SIZE);
	double my_even_median2 = find_median2(even2, EVEN_SIZE);

	// compare results
	cout << "std_odd_median is " << std_odd_median << endl;
	cout << "my_odd_median1 is " << my_odd_median1 << endl;
	cout << "my_odd_median2 is " << my_odd_median2 << endl;

	cout << "std_even_median is " << std_even_median << endl;
	cout << "my_even_median1 is " << my_even_median1 << endl;
	cout << "my_even_median2 is " << my_even_median2 << endl;
}